EXPRESS — Protótipo demonstrativo

COMO ABRIR
1. Extraia o ficheiro ZIP.
2. Abra a pasta Express.
3. Abra index.html num navegador (Chrome recomendado).
4. Crie uma conta de demonstração. Após o cadastro, a aplicação abre diretamente a Carteira.
5. Na barra inferior, toque em Carteira para ver o saldo e os botões Depositar e Levantar / Sacar.

DEPÓSITOS E LEVANTAMENTOS
- Depósito mínimo inicial: 300 MT; horário 06h00–20h00.
- O número de depósito pode ser alterado pelo administrador.
- O cliente introduz o valor e a referência do pagamento; o pedido fica pendente.
- Levantamento mínimo inicial: 100 MT; taxa de 15%; horário 06h00–20h00.
- O cliente informa o valor, número de destino e nome do titular; processamento estimado de 4 a 10 horas.
- Os pedidos são analisados na área Admin > Finanças.

PAINEL ADMINISTRATIVO
Na demonstração, abra Admin e escolha “Abrir painel de demonstração”. Em Finanças, configure o número de depósito e as regras.

IMPORTANTE
Esta é uma demonstração que guarda dados apenas no navegador deste dispositivo. Não movimenta dinheiro real, não fornece autenticação segura, nem sincroniza dados entre clientes. Antes de publicar para uso real, é obrigatório implementar servidor/backend, base de dados, autenticação segura, proteção contra fraude e integração/verificação com o provedor de pagamentos. Não use os saldos demonstrativos para pagamentos reais.
